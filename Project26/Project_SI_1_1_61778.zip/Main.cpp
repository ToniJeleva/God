#include "Simulator.h"
int main()
{
	Simulator simulator;
	simulator.Run();
	system("pause");
	return 0;
}