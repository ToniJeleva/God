#ifndef ENUM_H
#define ENUM_H
enum State { Moving, Attacking, Eating, SearchFood, Sleeping, Analyzing, Unknown };

enum EntityType { entity, animal, human, god, unknown };
#endif